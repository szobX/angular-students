export class Student {
  id: number | undefined;
  index: undefined;
  firstName: string | undefined;
  lastName: string | undefined;
}
